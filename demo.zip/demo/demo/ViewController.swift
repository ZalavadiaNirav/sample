//
//  ViewController.swift
//  demo
//
//  Created by photoshop on 18/12/18.
//  Copyright © 2018 photoshop. All rights reserved.
//

import UIKit

class ViewController: DLHamburguerViewController {
    override func awakeFromNib() {
        self.contentViewController = self.storyboard?.instantiateViewController(withIdentifier: "DLDemoNavigationViewController")
        self.menuViewController = self.storyboard?.instantiateViewController(withIdentifier: "DLDemoMenuViewController")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view, typically from a nib.
    }


}

