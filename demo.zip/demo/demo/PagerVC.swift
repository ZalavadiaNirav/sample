//
//  PagerVC.swift
//  demo
//
//  Created by photoshop on 18/12/18.
//  Copyright © 2018 photoshop. All rights reserved.
//

import UIKit
import DTPagerController


class PagerVC: DTPagerController {

    
  //  init() {
   //     super.init(viewControllers: [])
   //     title = "View Controller"
   // }
    
  //  required init?(coder aDecoder: NSCoder) {
  //      fatalError("init(coder:) has not been implemented")
  //  }
   
   
    @IBAction func menuButtonTouched(_ sender: AnyObject) {
        self.findHamburguerViewController()?.showMenuViewController()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        
        perferredScrollIndicatorHeight = 4
        
       let storyboard1 = UIStoryboard(name: "Main", bundle: nil)
//        let firstVC1 = storyboard1.instantiateViewController(withIdentifier: "ViewController")
//        firstVC1.title = "One"
    
        let firstVC2 = storyboard1.instantiateViewController(withIdentifier: "FirstVC")
        firstVC2.title = "Two"
       // let storyboard1 = UIStoryboard(name: "Main", bundle: nil)
        let firstVC3 = storyboard1.instantiateViewController(withIdentifier: "SecondVC")
        firstVC3.title = "Three"

        
        viewControllers = [firstVC2,firstVC3];
        scrollIndicator.layer.cornerRadius = scrollIndicator.frame.height/2
        
       

        // Do any additional setup after loading the view.
    }
    

}
